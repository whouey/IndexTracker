class DownloadToS3Operator():
    pass